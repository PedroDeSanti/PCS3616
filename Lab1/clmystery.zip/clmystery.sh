cat inicio
ls
cat dica1 dica2 dica3 dica4 dica5 dica6 dica7 dica8
ls
cd misterio/
ls
head -n 20 automoveis
head -n 20 cena-do-crime
head -n 20 pessoas
grep "PISTA" cena-do-crime
grep -c "Annabel" pessoas
grep "Annabel" pessoas
cd associacoes/
ls
head -n 20 AAA
grep -c "Annabel" AAA
grep "Annabel" AAA
cd ..
grep -c "Annabel Church" *
grep -c "Annabel Church" automoveis
grep -n -A 2 -B 3 "Annabel Church" automoveis
grep "Annabel Church" pessoas
head -n 40 ruas/Vila_Hart | tail -n 1
head -n 179 ruas/Vila_Buckingham | tail -n 1
cd entrevistas/
cat entrevista-47246024
cat entrevista-699607
cd ..
grep -c "L337" automoveis
grep "L337" automoveis
grep -A 6 "L337" automoveis
grep "Erika Owens" pessoas
grep "Aron Pilhofer" pessoas
grep "Heather Billings" pessoas
grep "Joe Germuska" pessoas
grep "Rienne Lemeda" pessoas
grep "Jacqui Maher" pessoas
head -n 98 ruas/Rua_Trapelo | tail -n 1
head -n 145 ruas/Rua_Claybourne | tail -n 1
head -n 19 ruas/Rua_Culbert | tail -n 1
head -n 275 ruas/Rua_Plainfield | tail -n 1
head -n 284 ruas/Travessa_Dunstable | tail -n 1
head -n 224 ruas/Travessa_Andover | tail -n 1
cd entrevistas/
cat entrevista-5455315 
cat entrevista-1767435 
cat entrevista-2939888 
cat entrevista-29741223 
cat entrevista-9620713 
cat entrevista-904020 
cd ..
grep "Rienne Lemeda" *
cd associacoes/
grep "Rienne Lemeda" *
echo "Como este sujeito tem o carro que bate com as carcteristicas descritas por testemunhas, esta' fugido e faz parte de todas as associacoes que estavam na carteira encontrada, logo o assassino e':"
echo "Rienne Lemeda"